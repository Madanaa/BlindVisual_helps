# BlindVisual_helps

The Aim of our project is to guide the visually impaired folios to perceive the things in surrounding environment with a sole Android app, concisely which helps them to listen about the things which they can’t see. 

Masters Project:
Service Oriented and Architectures Design

Madan Lal

Project Specifications:
  - Application Platform:     Android
  - Emulator version:       Android Oreo
  - Development IDE:         IntelliJ Android Studio
  - Storage:                  Google Firebase
  - Visual Recogntn Platform: IBM Blue mix Node red (Watson)
  - Text to speech service:   Google speech service
  - Oprating System: 	Window 10
  

