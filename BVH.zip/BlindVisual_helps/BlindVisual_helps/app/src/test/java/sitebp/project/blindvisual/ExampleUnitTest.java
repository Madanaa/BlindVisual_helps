package bproject.blindvisual;

import org.junit.Test;

import static org.junit.Assert.*;

/*	Masters Project.
	Service Oriented and Architectures Design

	
	Madan Lal
	
*/

public class ExampleUnitTest
{
    @Test
    public void addition_isCorrect()
    {
        assertEquals(4, 2 + 2);
    }
}
